from calculadora import somar

def test_somar():
    assert somar(2, 3) == 5
