# Demo local

Exemplo simples para testar o Nexus Dev sem usar código pessoal.
