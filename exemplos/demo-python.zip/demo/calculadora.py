"""Exemplo para analisar no Nexus Dev."""

def somar(a: float, b: float) -> float:
    return a + b

def dividir(a: float, b: float) -> float:
    return a / b

if __name__ == "__main__":
    print(somar(2, 3))
